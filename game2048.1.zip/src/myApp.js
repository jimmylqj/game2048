/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
//require("src/GameBoxUi.js");

var MyLayer = cc.Layer.extend({
                              //isMouseDown:false,
                              //helloImg:null,
                              //helloLabel:null,
                              //circle:null,
                              //sprite:null,
                              
                              //单元格大小
                              cellSize:0,
                              
                              widding :5,
                              cellNum :4,
                              fontSize :96,
                              boxSize:0,
                              
                              scale:1,
                              ctor:function() {
                              this._super();
                              cc.associateWithNative( this, cc.Layer );
                              },
                              
                              init:function () {
                              
                              //////////////////////////////
                              // 1. super init first
                              this._super();
                              
                              /////////////////////////////
                              // 2. add a menu item with "X" image, which is clicked to quit the program
                              //    you may modify it.
                              // ask director the window size
                              var size = cc.Director.getInstance().getWinSize();
                              

                              if(size.width*4 == size.height*3){
                              
                                if(size.height <= 1024 ){
                                    this.fontSize = 96;
                                }else{
                                    this.fontSize = 96;
                                    this.widding = 20;
                              this.scale = (size.width-size.width%600)/600;
                                }
                              }else if(size.width >=1080){
                              this.fontSize = 96;
                              this.widding =40;
                              
                              this.scale = (size.width-size.width%600)/600;
                              }
                              //初始化三个菜单选项
                              var item = new Array();
                              var message = ["Single","Double","Web"];
                              
                              item[0] = cc.MenuItemImage.create(
                                                                "res/red-button-b-1.png",
                                                                "res/red-button-b-2.png",
                                                                function () {
                                                                changeScene(0);
                                                                },this);
                              item[1] = cc.MenuItemImage.create(
                                                                "res/red-button-b-1.png",
                                                                "res/red-button-b-2.png",
                                                                function () {
                                                                changeScene(1);
                                                                },this);
                              item[2] = cc.MenuItemImage.create(
                                                                "res/red-button-b-1.png",
                                                                "res/red-button-b-2.png",
                                                                function () {
                                                                this.changeScene(2);
                                                                },this);
                              for(var i = 0 ; i <3 ;i++){

                              item[i].setAnchorPoint(cc.p(0.5, 0.5));
                              
                              item[i].setPosition(cc.p(size.width/2, size.height/4*(3-i)));
                              
                              var m = cc.LabelTTF.create(message[i],"Arial",this.fontSize);
                              
                              item[i].addChild(m,5);
                              
                              m.setAnchorPoint(cc.p(0.5,0.5));
                              m.setPosition(cc.p(item[i].getContentSize().width/2,item[i].getContentSize().height/2));
                              
                              if(this.scale !=1);
                              //cc.log(this.scale);
                              item[i].setScale(this.scale);
                              
                              }
                              
                              var menu = cc.Menu.create(item[0],item[1],item[2]);
                              menu.setPosition(cc.p(0, 0));
                              this.addChild(menu, 1);
                              
                              //安卓菜单键返回键有效
                              this.setKeypadEnabled(true);

                              return true;
                              },
                              
                              keyBackClicked : function() {
                              cc.log("按下返回键");
                              cc.Director.getInstance().end();
                              },
                              
                              keyMenuClicked : function() {
                              cc.log("按下菜单键");
                              },
                              
                              onExit:function () {
                              this._super();
                              cc.unregisterTouchDelegate(this);
                              },

                              
                              });

var MyScene = cc.Scene.extend({
                              ctor:function() {
                              this._super();
                              cc.associateWithNative( this, cc.Scene );
                              },
                              
                              onEnter:function () {
                              this._super();
                              var layer = new MyLayer();
                              this.addChild(layer);
                              layer.init();
                              }
                              });

//转换场景
function changeScene(num) {
    var director = cc.Director.getInstance();
    
    var newScene = null;
    cc.log(num);
    if(num ==0){
        newScene = new SinglePlayScene();
    }else if (num ==1){
        newScene = new DoublePlayScene();
    }else if(num ==2){
        newScene = new WebPlayScene();
    }else if(num == 4){
        newScene = new MyScene();
    }
    
    // run
    if(newScene != null){
        director.replaceScene(newScene);
    }
}
