/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
//require("src/GameBoxUi.js");

var WebLayer = cc.Layer.extend({
                               
                               ip:"192.168.43.10",
                               port:9988,
                               //单元格大小
                               cellSize:0,
                               boxUi:null,
                               
                               //canMove:true,
                               //开始点击位置
                               touchStartPoint:null,
                               
                               widding :5,
                               cellNum :4,
                               fontSize :64,
                               boxSize:0,
                               //计分牌
                               scoreShow:null,
                               
                               stateLabel:null,
                               
                               
                               //遮罩
                               maskLayer:null,
                               //maskLayer2:null,
                               //按钮
                               backMenu:null,
                               startMenu:null,
                               //时间槽
                               timeBarLayer:null,
                               timeBar:null,
                               time:0,
                               roundTime:120,
                               //scokect连接
                               mySocket:null,
                               //连接信息显示
                               connectLabel:null,
                               //尝试连接次数
                               tryTime:0,
                               //是否已登录
                               login:false,
                               
                               //玩家id
                               playerId:0,
                               
                               scale:1,
                               
                               CodeEnum : {NONE:0 , LOGIN:1 , LOGINOUT:2 , SEARCH:3 , GAMEBEGIN:4 , MOVE:5 , OPPMOVE:6 , GAMEOVER:7 , GAMETIME:8},

                               //游戏结束
                               //gameOverLabel:null,
                               
                               ctor:function() {
                               this._super();
                               cc.associateWithNative( this, cc.Layer );
                               },
                               
                               init:function () {
                               
                               //////////////////////////////
                               // 1. super init first
                               this._super();
                               
                               /////////////////////////////
                               // 2. add a menu item with "X" image, which is clicked to quit the program
                               //    you may modify it.
                               // ask director the window size
                               var size = cc.Director.getInstance().getWinSize();
                               
                            
                               
                               if(size.width*4 == size.height*3){
                               if(size.height <= 1024 ){
                               this.fontSize = 48;
                               }else{
                               this.fontSize = 96;
                               this.widding = 20;
                               this.scale = (size.width-size.width%400)/400-1;
                               }
                               }else if(size.width >=1080){
                               this.fontSize = 96;
                               this.widding =10;
                               this.scale = (size.width-size.width%400)/400-1;
                               }
                               
                               //主面板
                               this.boxSize = size.width < size.height/2-this.widding*2 ? size.width :size.height/2-this.widding*2;
                               //this.background = cc.LayerColor.create(cc.c4f(238,228,218,125),backgroundSize,backgroundSize);
                               this.boxUi = new Array();
                               this.boxUi[0] = new GameBoxUi();
                               this.boxUi[0].init(this.boxSize,this.cellNum,this.widding);
                               this.boxUi[1] = new GameBoxUi();
                               this.boxUi[1].init(this.boxSize,this.cellNum,this.widding);
                               this.addChild(this.boxUi[0],10);
                               this.boxUi[0].setPosition(cc.p((size.width-this.boxSize)/2,0));
                               this.boxUi[1].setPosition(cc.p((size.width-this.boxSize)/2,size.height-this.boxSize));
                               //this.boxUi[1].setRotation(180);
                               this.addChild(this.boxUi[1],10);
                
                               
                               this.maskLayer = new Array();
                               this.maskLayer[0] = cc.LayerColor.create(cc.c4f(250,250,250,200),size.width,this.boxSize);
                               this.maskLayer[1] = cc.LayerColor.create(cc.c4f(250,250,250,200),size.width,this.boxSize);
                               this.maskLayer[1].setPosition(cc.p(0,this.boxUi[1].getPosition().y));
                               
                               //this.maskLayer[1].setRotation(180);
                               this.addChild(this.maskLayer[0],20);
                               this.addChild(this.maskLayer[1],20);
                               //分数显示
                               this.scoreShow = new Array();
                               
                               //输赢显示
                               this.stateLabel = new Array();
                               
                               
                               for(var i=0 ;i<2;i++){
                               
                               this.scoreShow[i] = cc.LabelTTF.create("0","Arial",this.boxSize/3);
                               this.scoreShow[i].setFontFillColor(cc.c3b(0,0,0));
                               this.maskLayer[i].addChild(this.scoreShow[i],20);
                               this.scoreShow[i].setPosition(cc.p(size.width/2,this.boxSize/3*2));
                               this.scoreShow[i].setVisible(false);
                               
                               this.stateLabel[i] = cc.LabelTTF.create("Wait","Arial",this.boxSize/3);
                               this.stateLabel[i].setFontFillColor(cc.c3b(0,0,0));
                               this.maskLayer[i].addChild(this.stateLabel[i],20);
                               this.stateLabel[i].setPosition(cc.p(size.width/2,this.boxSize/3));
                               this.stateLabel[i].setVisible(false);
                               }
                               
                               
                               //this.stateLabel[1].setVisible(true);
                               
                               //时间层
                               
                               this.timeBarLayer = cc.LayerColor.create(cc.c4f(250,250,250,200),size.width,size.height-this.boxSize*2);
                               this.timeBarLayer.setPosition(cc.p(0,this.boxSize));
                               this.addChild(this.timeBarLayer,20);
                               
                               this.timeBar = cc.LayerColor.create(cc.c4f(250,25,25,200),this.boxSize,size.height-this.boxSize*2);
                               this.timeBar.setPosition(cc.p(size.width/2,this.boxSize));
                               this.addChild(this.timeBar,10);
                               this.timeBar.setVisible(false);
                               this.timeBar.ignoreAnchorPointForPosition(false);
                               this.timeBar.setAnchorPoint(cc.p(0.5,0));
                               
                               //开始按钮
                               var newGameItem = cc.MenuItemImage.create(
                                                                         "res/red-button-s-1.png",
                                                                         "res/red-button-s-2.png",
                                                                         function(){
                                                                         this.search()},this);
                               newGameItem.setAnchorPoint(cc.p(1, 0.5));
                               
                               this.startMenu = cc.Menu.create(newGameItem);
                               this.startMenu.setPosition(cc.p(size.width-this.widding, this.timeBarLayer.getContentSize().height/2));
                               this.timeBarLayer.addChild(this.startMenu, 25);
                               
                               
                               var buttonSize = newGameItem.getContentSize();
                               var newGameLabel = cc.LabelTTF.create("Search", "Arial", 40);
                               newGameLabel.setPosition(cc.p(buttonSize.width/2,buttonSize.height/2));
                               newGameItem.addChild(newGameLabel);
                               
                               newGameItem.setScale(this.scale);
                               
                               newGameItem.setVisible(true);
                               
                               this.startMenu.setVisible(false);
                               //返回按钮
                               var backItem = cc.MenuItemImage.create(
                                                                      "res/red-button-s-1.png",
                                                                      "res/red-button-s-2.png",
                                                                      function(){
                                                                      this.back()
                                                                      },this);
                               backItem.setAnchorPoint(cc.p(0, 0.5));
                               
                               this.backMenu = cc.Menu.create(backItem);
                               this.backMenu.setPosition(cc.p(this.widding, this.timeBarLayer.getContentSize().height/2));
                               this.timeBarLayer.addChild(this.backMenu, 25);
                               
                               var backLabel = cc.LabelTTF.create("Back", "Arial", 40);
                               backItem.addChild(backLabel);
                               backLabel.setPosition(cc.p(buttonSize.width/2,buttonSize.height/2));
                               
                               backItem.setScale(this.scale);
                               
                               //连接信息显示
                               this.connectLabel = cc.LabelTTF.create("wait","Arial",backItem.getContentSize().height);
                               this.connectLabel.setFontFillColor(cc.c3b(0,0,0));
                               this.connectLabel.setPosition(cc.p(size.width/2,size.height/2+backItem.getContentSize().height));
                               this.addChild(this.connectLabel,30);
                               
                               //注册触摸
                               this.addTargetedDelegate(this,10);
                               //this.setIsTouchEnabled(false);
                               //新建scokect
                               this.mySocket = yoomon.MySocket.shareMySocket();
                               this.mySocket.threadStart();
                               this.mySocket.cleanScoketMessage();
                               this.mySocket.threadPause();
                               
                               //网络连接监听定时器
                               this.schedule(this.updateLogin,1);
                               this.schedule(this.updateSocket,0.1);
                               
                               return true;
                               },
                               
                               addTargetedDelegate : function (node, priority){
                               if ("opengl" in sys.capabilities && "browser" != sys.platform){
                               cc.registerTargetedDelegate(priority, true, node);
                               //cc.log("fti");
                               //cc.registerStandardDelegate(node);
                               }
                               else {
                               cc.Director.getInstance().getTouchDispatcher().addTargetedDelegate(node, priority, true);
                               }
                               //this.setTouchEnabled(true);
                               },
                               
                               onTouchBegan : function(touches,touchEvent){
                               
                               
                               this.touchStartPoint = cc.Director.getInstance().convertToGL(touches.getLocationInView());
                               
                               
                               return true;},
                               
                               onTouchMoved : function(touches,touchEvent){
                               //cc.log("touches move !");
                               },
                               
                               onTouchEnded : function(touches,touchEvent){
                               //cc.log("touches end !");
                               
                               if(this.touchStartPoint != null && this.boxUi[0].canMove && !this.maskLayer[0].isVisible()){
                               var endPoint = touches.getLocationInView();
                               endPoint = cc.Director.getInstance().convertToGL(endPoint);
                               var x1 = (endPoint.x-this.touchStartPoint.x)*(endPoint.x-this.touchStartPoint.x);
                               var y1 =(endPoint.y-this.touchStartPoint.y)*(endPoint.y-this.touchStartPoint.y);
                               //cc.log(x1+","+y1);
                               
                               
                               var tempD = 0;
                               if(x1!=y1 && (x1 >=6400 || y1 >= 6400)){
                               x1>y1 ?  endPoint.x >this.touchStartPoint.x ? tempD = 2 : tempD = 4 : endPoint.y >this.touchStartPoint.y ? tempD = 1 : tempD = 3;
                               }
                               if(tempD !=0){
                               this.moveAction(boxUi[0],tempD);
                               }
                               this.touchStartPoint = null;
                               }
                               
                               },
                               
                               moveAction : function(boxUi,dir){
                               if(boxUi.canMove){
                               
                               if(dir !=0){
                               var havemove = boxUi.gameBox.move(dir);
                               
                               if(havemove){
                               boxUi.canMove= false;
                               
                               var action_call_back = cc.CallFunc.create(boxUi.upgrateShow(),this,null);
                               
                               var delay=cc.DelayTime.create(boxUi.actionTime);
                               //oldCell.setTag(after);
                               var action_call_back1 = cc.CallFunc.create(function(){boxUi.addNum(false);boxUi.canMove = true;},this,null);
                               
                               var action_call_backU = cc.CallFunc.create(function(){if(boxUi.gameBox.gameOver()){
                                                                          cc.log("over");
                                                                          boxUi.canMove = false;
                                                                          
                                                                          }},this,null);
                               
                               var seq1 = cc.Sequence.create(action_call_back,delay, action_call_back1,action_call_backU);
                               
                               this.runAction(seq1);
                               
                               
                               }
                               }
                               }
                               },
                               
                               onTouchesCancell : function(touches,touchEvent){
                               //cc.log("touches cancell !");
                               
                               this.touchStartPoint = null;

                               },
                               
                               
                               //发送寻找信号
                               search : function(){
                               //this.boxUi[0].newGame();
                               
                               this.scoreShow[0].setVisible(false);
                               this.scoreShow[1].setVisible(false);
                               this.stateLabel[0].setVisible(false);
                               this.stateLabel[1].setVisible(false);
                               
                               this.connectLabel.setVisible(true);
                               
                               this.mySocket.sendMessage(this.playerId,this.CodeEnum.SEARCH);
                               this.connectLabel.setString("searching");
                               this.startMenu.setVisible(false);
                               //this.boxUi[1].newGame();
                               //this.maskLayer[0].setVisible(false);
                               //this.maskLayer[1].setVisible(false);
                               //this.timeBarLayer.setVisible(false);
                               //this.timeBar.setVisible(true);
                               //this.canMove = true;
                               

                               },
                               
                               back :function(){
                               //cc.log("back");
                               //终止接受
                               this.mySocket.threadStop();
                               //判断是否悠登录
                               if(this.mySocket.getConnetAction()){
                               if(this.login){
                               //发送登出信息
                               this.mySocket.sendMessage(this.playerId,this.CodeEnum.LOGINOUT);
                               }
                               }
                               var director = cc.Director.getInstance();
                               var scene = new MyScene();
                               director.replaceScene(scene);
                               },
                               
                               //显示结果
                               showScore :function(){
                               if(this.touchStartPoint != null){
                               this.touchStartPoint = null;
                               }
                               var score0 = this.boxUi[0].gameBox.getTotalScore();
                               var score1 = this.boxUi[1].gameBox.getTotalScore();
                               this.scoreShow[0].setString(score0);
                               this.scoreShow[1].setString(score1);
                               if(score0 > score1){
                               this.stateLabel[0].setString("Win");
                               this.stateLabel[1].setString("Lose");
                               }else if(score1 > score0){
                               this.stateLabel[0].setString("Lose");
                               this.stateLabel[1].setString("Win");
                               }else{
                               this.stateLabel[0].setString("Draw");
                               this.stateLabel[1].setString("Draw");
                               }
                               this.scoreShow[0].setVisible(true);
                               this.scoreShow[1].setVisible(true);
                               this.stateLabel[0].setVisible(true);
                               this.stateLabel[1].setVisible(true);
                               
                               this.backMenu.setVisible(true);
                               
                               if(this.mySocket.getConnetAction()){
                               
                                    if(this.login){
                                    this.startMenu.setVisible(true);
                                    }
                               }
                               this.layerState(true);
                               },
                               
                               layerState : function(b){
                               this.maskLayer[0].setVisible(b);
                               this.maskLayer[1].setVisible(b);
                               this.timeBarLayer.setVisible(b);
                               this.timeBar.setVisible(!b);
                               
                               },
                               
                               readyAction : function(){
                               
                               this.connectLabel.setString("ready");
                               
                               this.backMenu.setVisible(false);
                               
                               var delay=cc.DelayTime.create(1);
                               //oldCell.setTag(after);
                               var action_call_back1 = cc.CallFunc.create(function(){this.connectLabel.setString("3");},this,null);
                               
                               var action_call_back2 = cc.CallFunc.create(function(){this.connectLabel.setString("2");},this,null);
                               
                               var action_call_back3 = cc.CallFunc.create(function(){this.connectLabel.setString("1");},this,null);
                               
                               var action_call_backU = cc.CallFunc.create(function(){this.layerState(false);
                                                                          this.time = this.roundTime;
                                                                          this.connectLabel.setVisible(false);
                                                                          this.updateTimeBar(0);
                                                                          
                                                                          //恢复定时器监听
                                                                          this.schedule(this.updateT,0.1);
                                                                          },this,null);
                               
                               var seq1 = cc.Sequence.create(delay,action_call_back1,delay, action_call_back2,delay,action_call_back3,delay,action_call_backU);
                               
                               this.runAction(seq1);
                               },
                               
                               updateT : function(){this.updateTimeBar(0.1)},
                               
                               updateSocket:function(){
                               //cc.log("socket");
                               if(this.mySocket.getConnetAction() && this.login){
                               
                               var backMessage = this.mySocket.getSocketMessage();
                               if(backMessage){
                               
                               var array = backMessage.split(":");
                               //cc.log(array[0]);
                               //cc.log(this.CodeEnum.GAMEBEGIN);
                               switch(true){
                               //游戏开始
                               case array[0] == this.CodeEnum.GAMEBEGIN :{
                               //cc.log("begin");
                               this.boxUi[0].setBoxMessage(array[1]);
                               this.boxUi[1].setBoxMessage(array[2]);
                               this.readyAction();
                               break;
                               }
                               //对手移动
                               case array[0] == this.CodeEnum.OPPMOVE :{
                                    this.boxUi[1].setBoxMessage(array[2]);
                               break;
                               }
                               
                               case array[0] == this.CodeEnum.GAMEOVER :{
                               //
                               cc.log("game over");
                               this.boxUi[0].setBoxMessage(array[2]);
                               this.boxUi[1].setBoxMessage(array[4]);
                               this.showScore();
                               this.mySocket.cleanScoketMessage();
                               break;
                               }
                               case array[0] == this.CodeEnum.GAMETIME :{
                               
                               if(this.time != array[1]){
                               cc.log("time:"+array[1]);
                               this.time = array[1];
                               }
                               break;
                               }
                               default :{
                               cc.log("error");
                               break;}
                               }
                               
                               }
                               }
                               },
                               
                               updateLogin:function(){
                               //cc.log("login");
                               if(this.mySocket.getConnetAction()){
                               
                               if(!this.login){
                               
                               this.mySocket.threadResume();
                               var backMessage = this.mySocket.getSocketMessage();
                               
                               if(backMessage){
                               var array = backMessage.split(":");
                               if(array[0] == 1){
                               //回送登录id
                               this.playerId = array[1];
                               this.mySocket.sendMessage(this.playerId,this.CodeEnum.LOGIN);
                               this.login = true;
                               this.connectLabel.setString("ok");
                               this.startMenu.setVisible(true);
                               this.tryTime = 0;
                               
                               }
                               }else{
                               
                               this.mySocket.sendMessage(this.playerId,this.CodeEnum.LOGIN);
                               
                               }
                               }
                               }else{
                               
                               this.startMenu.setVisible(false);
                               this.backMenu.setVisible(true);
                               this.layerState(true);
                               
                               this.scoreShow[0].setVisible(false);
                               this.scoreShow[1].setVisible(false);
                               this.stateLabel[0].setVisible(false);
                               this.stateLabel[1].setVisible(false);
                               
                               this.connectLabel.setVisible(true);
                               
                               this.playerId = 0;
                               this.tryTime++;
                               if(this.tryTime < 10){
                               this.connectLabel.setString("wait");
                               
                               }else{
                               this.connectLabel.setString("check connect");
                               }
                               this.login = false;
                               this.mySocket.connect(this.ip, this.port);
                               }
                               },
                               
                               //更新时间条
                               updateTimeBar : function(dt){
                               //cc.log(dt);
                               if(this.time == 0){
                               //cc.log("time out");
                               //停止时间器
                               this.unschedule(this.updateT);
                               //this.showScore();
                               }else{
                               //cc.log(this.time);
                               this.time = this.time - dt;
                               if(this.time < 0){
                               this.time = 0;
                               }
                               this.timeBar.changeWidth(this.boxSize*this.time/this.roundTime);
                               }
                               },
                               
                               
                               onExit:function () {
                               this._super();
                               cc.unregisterTouchDelegate(this);
                               },
                               
                               
                               });

var WebPlayScene = cc.Scene.extend({
                                   ctor:function() {
                                   this._super();
                                   cc.associateWithNative( this, cc.Scene );
                                   },
                                   
                                   onEnter:function () {
                                   this._super();
                                   var layer = new WebLayer();
                                   this.addChild(layer);
                                   layer.init();
                                   }
                                   });
