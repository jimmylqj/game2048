/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

var GameBoxUi = cc.LayerColor.extend({

                                     //数据
                                     gameBox:null,
                                     cellSize:0,
                                     cellNum:0,
                                     widding:10,
                                     //显示数字层
                                     cellLayer:null,
                                     
                                     canMove:true,

                                     actionTime:0.1,
                                     
                                     ctor:function() {
                                     this._super();
                                     cc.associateWithNative( this, cc.LayerColor);
                                     },
                                     
                                     init:function (size,row,widding) {
                                     this._super();
                                     this.setColor(cc.c3b(238,228,218));
                                     this.setOpacity(125);
                                     this.changeWidthAndHeight(size,size);

                                     this.cellNum = row;
                                     this.widding = widding;
                                     this.cellSize = (size-(this.cellNum+1)*this.widding)/this.cellNum;
                                     
                                     
                                     for(var i=0;i < this.cellNum; i++){
                                     for(var j=0;j < this.cellNum; j++){
                                     var cell = cc.LayerColor.create(this.getBackgrondColor(0),this.cellSize,this.cellSize);
                                     cell.setPosition(this.getPositionByRC(i*4+j));
                                     this.addChild(cell,5);
                                     //cc.log("add");
                                     
                                     this.cellLayer = cc.Layer.create();
                                     this.addChild(this.cellLayer,10);
                                     }
                                     }
                                     
                                     
                                     this.gameBox = new yoomon.GameBox();
                                     
                                     //this.addTargetedDelegate(this,10);
                                     },
                                     
                                     getPositionByRC : function(index){
                                     var row = (index-index%this.cellNum)/this.cellNum;
                                     var col = index%this.cellNum;
                                     return cc.p(this.widding+col*(this.widding+this.cellSize),this.getContentSize().width-(this.widding+this.cellSize)*(row+1));
                                     },
                                     //获得背景色
                                     getBackgrondColor : function(num){
                                     if(num == 0){
                                     return cc.c4f(238, 228,218,88);
                                     }else if(num == 2){
                                     return cc.c4f(238,228,218,250);
                                     }else if(num == 4){
                                     return cc.c4f(237,224,200,250);
                                     }else if(num == 8){
                                     return cc.c4f(242,166,121,250);
                                     }else if(num == 16){
                                     return cc.c4f(245,149,99,250);
                                     }else if(num == 32){
                                     return cc.c4f(246,124,105,250);
                                     }else if(num == 64){
                                     return cc.c4f(246,104,59,250);
                                     }else if(num == 128){
                                     return cc.c4f(237,207,114,250);
                                     }else if(num == 256){
                                     return cc.c4f(237,204,97,250);
                                     }else if(num == 512){
                                     return cc.c4f(237,200,90,250);
                                     }else if(num == 1024){
                                     return cc.c4f(237,197,63,250);
                                     }else if(num == 2048){
                                     return cc.c4f(237,194,46,250);
                                     }else if(num > 2048){
                                     return cc.c4f(60,58,50,200);
                                     }
                                     
                                     },
                                     
                                     //移动单元格
                                     moveCellShow : function(before,after,num){
                                     //cc.log("moveOnly:");
                                     var action_call_back = cc.CallFunc.create(this.moveCellAction(before,after),this,null);
                                     
                                     //oldCell.setTag(after);
                                     var action_call_back1 = cc.CallFunc.create(this.changeTag(before,after),this,null);
                                     
                                     //var action_call_backU = cc.CallFunc.create(this.addCellShow(after,num),this,null);
                                     
                                     var seq1 = cc.Sequence.create(action_call_back, action_call_back1);
                                     
                                     this.runAction(seq1);
                                     
                                     //this.cleanMove(after);
                                     },
                                     
                                     //移动动作
                                     moveCellAction :function(before,after){
                                     var oldCell  = this.cellLayer.getChildByTag(before);
                                     //cc.log(before+" to "+after);
                                     var action  = cc.MoveTo.create(this.actionTime,this.getPositionByRC(after));
                                     oldCell.runAction(action);
                                     },
                                     
                                     //改变单元格标记
                                     changeTag :function(before,after){
                                     var oldCell  = this.cellLayer.getChildByTag(before);
                                     oldCell.setTag(after);
                                     },
                                     
                                     //合并单元格
                                     unitedCell : function(before,after,end,num){
                                     
                                     //                              var oldCell1  = this.background.getChildByTag(before);
                                     //                              var oldCell2  = this.background.getChildByTag(after);
                                     //
                                     //
                                     //                              var action1  = cc.MoveTo.create(0.1,this.getPositionByRC(end));
                                     //cc.log("united:"+before+" and "+ after +" to "+end);
                                     var action_call_back1_1 = cc.CallFunc.create(this.moveCellAction(before,end),this,null);
                                     
                                     //var action_call_back1 = cc.CallFunc.create(this.removeCell(before),this,null);
                                     
                                     
                                     var action_call_backU = cc.CallFunc.create(this.addCellShow(end,num),this,null);
                                     
                                     var action_call_back1 =null;
                                     var seq1 = null;
                                     if(end != before){
                                     //action_call_back1 = cc.CallFunc.create(this.changeTag(before,end),this,null);
                                     action_call_back1 = cc.CallFunc.create(this.removeCell(before),this,null);
                                     seq1 = cc.Sequence.create(action_call_back1_1, action_call_back1,action_call_backU);
                                     }else{
                                     seq1 = cc.Sequence.create(action_call_back1_1,action_call_backU);
                                     //
                                     }
                                     
                                     
                                     this.runAction(seq1);
                                     
                                     
                                     //var action2  = cc.MoveTo.create(0.1,this.getPositionByRC(end));
                                     var action_call_back2_2 = cc.CallFunc.create(this.moveCellAction(after,end),this,null);
                                     
                                     var action_call_back2 = cc.CallFunc.create(this.removeCell(after),this,null);
                                     
                                     
                                     var seq2 = cc.Sequence.create(action_call_back2_2, action_call_back2);
                                     
                                     
                                     this.runAction(seq2);
                                     
                                     //this.addCellShow(end);
                                     },
                                     
                                     removeCell :function(index){
                                     var tagNum = index;
                                     //cc.log("remove tag:"+index);
                                     var oldCell  = this.cellLayer.getChildByTag(index);
                                     //this.background.removeChildByTag(tagNum);
                                     this.cellLayer.removeChild(oldCell,true);
                                     },

                                     //增加单元格
                                     addCellShow : function(index , num){
                                     var labelTag = 1;
                                     var bacjgroundTag =2;
                                     
                                     var oldCell  = this.cellLayer.getChildByTag(index);
                                     if(oldCell ==null){
                                     var numLabel = cc.LabelTTF.create(num, "Arial", this.getNumSize(num));
                                     numLabel.setAnchorPoint(cc.p(0.5,0.5));
                                     numLabel.setPosition(cc.p(this.cellSize/2,this.cellSize/2));
                                     numLabel.setFontFillColor(this.getNumColor(num));
                                     //                              var alignment = 1;
                                     //                              numLabel.setHorizontalAlignment(alignment);
                                     cellbackground = cc.LayerColor.create(this.getBackgrondColor(num),this.cellSize,this.cellSize);
                                     cellbackground.addChild(numLabel,5,labelTag);
                                     cellbackground.setAnchorPoint(cc.p(0,0));
                                     cellbackground.setPosition(this.getPositionByRC(index));
                                     this.cellLayer.addChild(cellbackground,20,index);
                                     //cc.log("add num:"+num+",index:"+index);
                                     }else{
                                     var label = oldCell.getChildByTag(labelTag);
                                     label.setString(num);
                                     label.setFontFillColor(this.getNumColor(num));
                                     label.setFontSize(this.getNumSize(num));
                                     oldCell.setColor(this.getBackgrondColor(num));
                                     }
                                     
                                     },
                                     
                                     getNumColor : function(num){
                                     if(num<= 2048){
                                     return cc.c3b(0,0,0);
                                     }else{
                                     return cc.c3b(250,250,250);
                                     }
                                     },
                                     
                                     getNumSize : function(num){
                                     var size = this.cellSize/2;
                                     
                                     if(num <= 999){
                                        return size;
                                     }else {
                                        var add = 1;
                                        var yu = num/1000;
                                        while(yu >= 10){
                                            add++;
                                            yu =yu/10;
                                        }
                                        return size*3/(3+add);
                                     }
                                     },
                                     

                                     
                                     
                                     upgrateShow : function(){
                                     for(var i = 0 ;i < this.cellNum ; i++){
                                     for(var j = 0; j < this.cellNum ; j++){
                                     var listNum = this.gameBox.getList(i,j);
                                     //cc.log("list:"+listNum);
                                     var cellTemp = this.gameBox.getCell((listNum-listNum%this.cellNum)/this.cellNum,listNum%this.cellNum);
                                     var cellNum = cellTemp.getScore();
                                     var cellShow = this.getChildByTag(listNum);
                                     var nowIndex = cellTemp.getNowIndex();
                                     //                              if(cellNum > 0){
                                     //                              cc.log("num:"+cellNum+" in:"+nowIndex);
                                     //                              }
                                     if(cellNum > 0 && cellTemp.haveMove()){
                                     this.moveCellShow(cellTemp.getOldIndex1(),nowIndex,cellNum);
                                     this.cleanMove(nowIndex);
                                     }else if(cellNum > 0 && cellTemp.haveUnited()){
                                     var oldIndex1 = cellTemp.getOldIndex1();
                                     var oldIndex2 = cellTemp.getOldIndex2();
                                     
                                     this.unitedCell(oldIndex1,oldIndex2, nowIndex ,cellNum);
                                     this.cleanMove(nowIndex);
                                     }else if(cellNum > 0 && !cellShow)
                                     this.addCellShow(nowIndex,cellNum);
                                     this.cleanMove(nowIndex);
                                     }
                                     
                                     //cellTemp.cleanOldIndex();
                                     //                              cellTemp.setOldIndex1(-1);
                                     //                              cellTemp.setOldIndex2(-1);
                                     }
                                     
                                     },
                                     
                                     
                                     
                                     
                                     
                                     //清除合并移动信息
                                     cleanMove : function(index){
                                     var cellone = this.gameBox.getCell((index-index%this.cellNum)/this.cellNum,index%this.cellNum);
                                     cellone.cleanOldIndex();
                                     },

                                     newGame : function(isSave){
                                     cc.log("newGame");
                                     this.cleanGame();
                                     this.gameBox.randomNum();
                                     this.gameBox.randomNum();
                                     if(isSave){
                                     this.gameBox.save();
                                     }
                                     this.upgrateShow();
                                     this.canMove = true;
                                     },
                                     //清除ui和数据
                                     cleanGame : function(){
                                     
                                     for(var i =0 ;i< this.cellNum*this.cellNum;i++){
                                     
                                     var cell = this.cellLayer.getChildByTag(i);
                                     
                                     if(cell != null){
                                     this.cellLayer.removeChild(cell);
                                     
                                     }
                                     
                                     }
                                     this.gameBox.gameClean();
                                     },
                                     
                                     loadGame : function(){
                                     this.gameBox.load();
                                     this.upgrateShow();

                                     },
                                     
                                     addNum : function(isSave){
                                        this.gameBox.randomNum();
                                     this.upgrateShow();
                                     if(isSave){
                                     this.gameBox.save();
                                     }
                                     },
//                                     onEnter:function () {
//                                     
//                                     this._super();
//                                     }
                                     //获得数据字符串
                                     getBoxMessage : function(){
                                        return this.gameBox.getBoxMessage();
                                     },
                                     
                                     //设置数据并更新ui
                                     setBoxMessage : function(str){
                                     
                                     this.cleanGame();
                                     
                                     var array = str.split("|");
                                     
                                     for(var i = 0 ; i < this.cellNum ; i++){
                                     for(var j = 0 ; j < this.cellNum ; j++){
                                     //var listNum = this.gameBox.getList(i,j);
                                     //cc.log("i:"+i +" j:"+ j + " num:"+array[i*this.cellNum+j]);
                                     var cellTemp = this.gameBox.getCell(i,j);
                                        cellTemp.setScore(array[i*this.cellNum+j]);
                                     }
                                     }
                                     
                                     this.gameBox.addTotalScore( array[this.cellNum*this.cellNum] );
                                     
                                     this.upgrateShow();
                                     }

});