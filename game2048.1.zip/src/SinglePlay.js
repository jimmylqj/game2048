/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
//require("src/GameBoxUi.js");

var SinglePlayLayer = cc.Layer.extend({
                              isMouseDown:false,
                              //helloImg:null,
                              //helloLabel:null,
                              circle:null,
                              //sprite:null,
                              
                              //单元格大小
                              cellSize:0,
                              boxUi:null,

                            //开始点击位置
                              touchStartPoint:null,
                              
                              widding :10,
                              cellNum :4,
                              fontSize :64,
                              //计分牌
                              scoreShow:null,
                              scoreLabel:null,
                              //最高分
                              highScoreShow:null,
                              highScoreLabel:null,
                              //游戏结束
                              gameOverLabel:null,
                              
                                      scale:1,
                              ctor:function() {
                              this._super();
                              cc.associateWithNative( this, cc.Layer );
                              },
                              
                              init:function () {
                              
                              //////////////////////////////
                              // 1. super init first
                              this._super();
                              
                              /////////////////////////////
                              // 2. add a menu item with "X" image, which is clicked to quit the program
                              //    you may modify it.
                              // ask director the window size
                              var size = cc.Director.getInstance().getWinSize();
                              
                              // add a "close" icon to exit the progress. it's an autorelease object
//                              var closeItem = cc.MenuItemImage.create(
//                                                                      "res/CloseNormal.png",
//                                                                      "res/CloseSelected.png",
//                                                                      function () {
//                                                                      cc.log("close button was clicked.");
//                                                                      },this);
//                              closeItem.setAnchorPoint(cc.p(0.5, 0.5));
//                              
//                              var menu = cc.Menu.create(closeItem);
//                              menu.setPosition(cc.p(0, 0));
//                              this.addChild(menu, 1);
//                              closeItem.setPosition(cc.p(size.width - 20, 20));
                              
                              /////////////////////////////
                              // 3. add your codes below...
                              // add a label shows "Hello World"
                              // create and initialize a label
                              //        this.helloLabel = cc.LabelTTF.create("Hello World", "Arial", 38);
                              //        // position the label on the center of the screen
                              //        this.helloLabel.setPosition(cc.p(size.width / 2, size.height - 40));
                              //        // add the label as a child to this layer
                              //        this.addChild(this.helloLabel, 5);
                              //
                              //        // add "Helloworld" splash screen"
                              //        this.sprite = cc.Sprite.create("res/HelloWorld.png");
                              //        this.sprite.setAnchorPoint(cc.p(0.5, 0.5));
                              //        this.sprite.setPosition(cc.p(size.width / 2, size.height / 2));
                              
                              //        this.addChild(this.sprite, 0);
                              if(size.width*4 == size.height*3){
                              if(size.height <= 1024 ){
                              this.fontSize = 48;
                              }else{
                              this.fontSize = 96;
                              this.widding = 20;
                                      this.scale = (size.width-size.width%400)/400-1;
                              }
                              }else if(size.width >=1080){
                              this.fontSize = 96;
                              this.widding =20;
                            this.scale = (size.width-size.width%400)/400-1;
                              }
                              
                              //主面板
                              var backgroundSize = size.width< size.height ? size.width :size.height;
                              //this.background = cc.LayerColor.create(cc.c4f(238,228,218,125),backgroundSize,backgroundSize);
                              this.boxUi = new GameBoxUi();
                              this.boxUi.init(backgroundSize,this.cellNum,this.widding);
                              
                              this.addChild(this.boxUi,10);
                              
                              //开始按钮
                              var newGameItem = cc.MenuItemImage.create(
                                                                        "res/red-button-s-1.png",
                                                                        "res/red-button-s-2.png",
                                                                        function(){
                                                                        this.newGame()},this);
                              newGameItem.setAnchorPoint(cc.p(1, 1));
                              
                              var newGameMenu = cc.Menu.create(newGameItem);
                              newGameMenu.setPosition(cc.p(0, 0));
                              this.addChild(newGameMenu, 2);
                              newGameItem.setPosition(cc.p(size.width-this.widding , size.height - this.widding));
                              
                              var buttonSize = newGameItem.getContentSize();
                                      //buttonSize.height = buttonSize.height*this.scale;
                                      //buttonSize.width = buttonSize.width*this.scale;
                                      
                              var newGameLabel = cc.LabelTTF.create("Reset", "Arial", 40);
                              newGameLabel.setPosition(cc.p(buttonSize.width/2,buttonSize.height/2));
                                newGameLabel.setAnchorPoint(cc.p(0.5,0.5));
                              newGameItem.addChild(newGameLabel);
                                      
                                newGameItem.setScale(this.scale);
                              //返回按钮
                              var backItem = cc.MenuItemImage.create(
                                                                        "res/red-button-s-1.png",
                                                                        "res/red-button-s-2.png",
                                                                        function(){
                                                                     var director = cc.Director.getInstance();
                                                                     var scene = new MyScene();
                                                                     director.replaceScene(scene);
                                                                     //cc.log("back");
                                                                     },this);
                              backItem.setAnchorPoint(cc.p(0, 1));
                              
                              var backMenu = cc.Menu.create(backItem);
                              backMenu.setPosition(cc.p(0, 0));
                              this.addChild(backMenu, 2);
                              backItem.setPosition(cc.p(this.widding , size.height-this.widding));
                              var backLabel = cc.LabelTTF.create("Back", "Arial", 40);
                              backItem.addChild(backLabel);
                              backLabel.setPosition(cc.p(buttonSize.width/2,buttonSize.height/2));
                                      backItem.setScale(this.scale);
                              
                            buttonSize.height = buttonSize.height*this.scale;
                              var topbar = cc.LayerColor.create(cc.c4f(238,228,218,150),size.width,buttonSize.height+this.widding*2);
                              topbar.ignoreAnchorPointForPosition(false);
                              topbar.setAnchorPoint(cc.p(0,1));
                              topbar.setPosition(cc.p(0,size.height));
                              this.addChild(topbar,0);
                             
                              //分数
                              this.scoreLabel = cc.LabelTTF.create("Score","Arial",this.fontSize);
                              this.scoreLabel.setAnchorPoint(cc.p(0,1));
                              this.scoreLabel.setPosition(cc.p(this.widding*2,size.height-(buttonSize.height+this.widding)-this.widding));
                              this.addChild(this.scoreLabel,2);
                              
                              this.scoreShow =cc.LabelTTF.create("0","Arial",this.fontSize);
                              
                              this.scoreShow.setAnchorPoint(cc.p(0.5,1));
                              this.updateScore();

                              this.addChild(this.scoreShow,2);
                              
                              //最高分数
                              this.highScoreLabel = cc.LabelTTF.create("Best","Arial",this.fontSize);
                              this.highScoreLabel.setAnchorPoint(cc.p(1,1));
                              this.highScoreLabel.setPosition(cc.p(size.width - this.widding*2,size.height-(buttonSize.height+this.widding)-this.widding));
                              this.addChild(this.highScoreLabel,2);
                              
                              this.highScoreShow =cc.LabelTTF.create("0","Arial",this.fontSize);
                              
                              this.highScoreShow.setAnchorPoint(cc.p(0.5,1));
                              
                              this.updateHighScore();
                              
                              this.addChild(this.highScoreShow,2);
                              

                              //this.background.setAnchorPoint(cc.p(0.5,0.5));
                              this.boxUi.setPosition(cc.p(0, this.highScoreShow.getPosition().y-this.highScoreShow.getContentSize().height-backgroundSize));
                              
                              //this.background.setRotation(90);
                              //this.cellSize = (backgroundSize-(this.cellNum+1)*this.widding)/this.cellNum;
                              
                              this.addTargetedDelegate(this,10);
                              
                              //游戏结束标签
                              this.gameOverLabel = cc.LabelTTF.create("Game Over","Arial",this.fontSize);
                              this.gameOverLabel.setAnchorPoint(cc.p(0.5,1));
                              this.gameOverLabel.setPosition(cc.p(size.width/2,this.boxUi.getPosition().y));
                              this.addChild(this.gameOverLabel,2);
                              this.gameOverLabel.setVisible(false);
                              this.loadGame();

                              return true;
                              },
                              
                              addTargetedDelegate : function (node, priority){
                              if ("opengl" in sys.capabilities && "browser" != sys.platform){
                              cc.registerTargetedDelegate(priority, true, node);
                              }
                              else {
                              cc.Director.getInstance().getTouchDispatcher().addTargetedDelegate(node, priority, true);
                              }
                              },
                              
                              onTouchBegan : function(touches,touchEvent){
                              //cc.log("touches confirm layer! block touchEvent bubble!");
                                      
                              this.touchStartPoint = cc.Director.getInstance().convertToGL(touches.getLocationInView());
                              return true;},
                              
                              onTouchMoved : function(touches,touchEvent){
                              //cc.log("touches move !");
                              },
                              
                              onTouchEnded : function(touches,touchEvent){
                              //cc.log("touches end !");

                              if(this.boxUi.canMove){
                                      var endPoint = touches.getLocationInView();
                                      endPoint = cc.Director.getInstance().convertToGL(endPoint);
                                      var x1 = (endPoint.x-this.touchStartPoint.x)*(endPoint.x-this.touchStartPoint.x);
                                      var y1 =(endPoint.y-this.touchStartPoint.y)*(endPoint.y-this.touchStartPoint.y);
                                      //cc.log(x1+","+y1);
                              
                              
                              var tempD = 0;
                              if(x1!=y1 && (x1 >=6400 || y1 >= 6400)){
                              x1>y1 ?  endPoint.x >this.touchStartPoint.x ? tempD = 2 : tempD = 4 : endPoint.y >this.touchStartPoint.y ? tempD = 1 : tempD = 3;
                              }
                              if(tempD !=0){
                              var havemove = this.boxUi.gameBox.move(tempD);
                              
                              
                              if(havemove){
                              this.boxUi.canMove= false;
                              
                              var action_call_back = cc.CallFunc.create(this.boxUi.upgrateShow(),this,null);
                              
                              var delay=cc.DelayTime.create(this.boxUi.actionTime);
                              //oldCell.setTag(after);
                              var action_call_back1 = cc.CallFunc.create(function(){this.boxUi.addNum(true);this.updateScore();if(this.boxUi.gameBox.getTotalScore() == this.boxUi.gameBox.getHighScore())this.updateHighScore();this.boxUi.canMove = true;},this,null);
                              
                              var action_call_backU = cc.CallFunc.create(function(){if(this.boxUi.gameBox.gameOver()){
                                                                         cc.log("over");
                                                                         this.boxUi.canMove = false;
                                                                         this.gameOverLabel.setVisible(true);
                                                                         }},this,null);
                              
                              var seq1 = cc.Sequence.create(action_call_back,delay, action_call_back1,action_call_backU);
                              
                              this.runAction(seq1);
                              
                              
                              }
                              }
                              this.touchStartPoint = null;
                              }
                              },
                              
                              onTouchCancell : function(touches,touchEvent){
                              //cc.log("touches cancell !");
                              this.touchStartPoint = null;
                              },
                              
                              
                              loadGame : function(){
                              this.boxUi.loadGame();
                              this.updateScore();
                              this.updateHighScore();
                              },
                              
                              newGame : function(){
                              this.boxUi.newGame(true);
                              this.updateScore();
                              this.gameOverLabel.setVisible(false);
                              this.boxUi.canMove = true;
                              },
                              
                              updateScore :function(){
                              this.scoreShow.setString(this.boxUi.gameBox.getTotalScore());
                              var labelSize =  this.scoreLabel.getContentSize();
                              var showSize = this.scoreShow.getContentSize();
                              var widthP = labelSize.width > showSize.width ? labelSize.width : showSize.width;
                            this.scoreShow.setPosition(cc.p(this.widding+widthP/2,this.scoreLabel.getPosition().y-labelSize.height));
                              },

                              
                              updateHighScore:function(){
                              this.highScoreShow.setString(this.boxUi.gameBox.getHighScore());
                              var labelSize =  this.highScoreLabel.getContentSize();
                              var showSize = this.highScoreShow.getContentSize();
                              var widthP = labelSize.width > showSize.width ? labelSize.width : showSize.width;
                              this.highScoreShow.setPosition(cc.p(this.highScoreLabel.getPositionX()-widthP/2,this.scoreLabel.getPosition().y-labelSize.height));
                              },
                              
                              onExit:function () {
                              this._super();
                              cc.unregisterTouchDelegate(this);
                              },

                              
                              });

var SinglePlayScene = cc.Scene.extend({
                              ctor:function() {
                              this._super();
                              cc.associateWithNative( this, cc.Scene );
                              },
                              
                              onEnter:function () {
                              this._super();
                              var layer = new SinglePlayLayer();
                              this.addChild(layer);
                              layer.init();
                              }
                              });
